import cv2
import mediapipe as mp
import numpy as np
import serial
import time

# ---------------- SERIAL SETUP ----------------
arduino = serial.Serial('COM4', 9600)  # CHANGE COM PORT IF NEEDED
time.sleep(2)

# ---------------- MEDIAPIPE SETUP ----------------
mp_face_mesh = mp.solutions.face_mesh
face_mesh = mp_face_mesh.FaceMesh(
    max_num_faces=1,
    refine_landmarks=True,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

# Eye landmark indices
LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]

# ---------------- CAMERA ----------------
cap = cv2.VideoCapture(0)

# ---------------- FUNCTIONS ----------------
def eye_aspect_ratio(landmarks, eye_indices):
    points = np.array([[landmarks[i].x, landmarks[i].y] for i in eye_indices])
    v1 = np.linalg.norm(points[1] - points[5])
    v2 = np.linalg.norm(points[2] - points[4])
    h = np.linalg.norm(points[0] - points[3])
    return (v1 + v2) / (2.0 * h)

# ---------------- PARAMETERS ----------------
EAR_THRESHOLD = 0.25
CLOSED_FRAMES = 15  # ~0.5 sec depending on FPS

closed_counter = 0
level_sent = -1  # prevent resending same value

# ---------------- MAIN LOOP ----------------
while True:
    ret, frame = cap.read()
    if not ret:
        break

    frame = cv2.flip(frame, 1)
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    results = face_mesh.process(rgb)

    level = 0  # default: eyes open

    if results.multi_face_landmarks:
        landmarks = results.multi_face_landmarks[0].landmark

        left_ear = eye_aspect_ratio(landmarks, LEFT_EYE)
        right_ear = eye_aspect_ratio(landmarks, RIGHT_EYE)
        avg_ear = (left_ear + right_ear) / 2.0

        if avg_ear < EAR_THRESHOLD:
            closed_counter += 1
        else:
            closed_counter = 0

        # -------- EYE CLOSURE LEVELS --------
        if closed_counter < CLOSED_FRAMES:
            level = 0            # Eyes open
        elif closed_counter < 45:
            level = 1            # Closed short
        elif closed_counter < 90:
            level = 2            # Closed medium
        else:
            level = 3            # Closed long

        # -------- SEND ONLY IF CHANGED --------
        if level != level_sent:
            arduino.write(str(level).encode())
            level_sent = level

        # -------- DISPLAY --------
        status_text = ["EYES OPEN", "CLOSED (SHORT)", "CLOSED (MEDIUM)", "CLOSED (LONG)"]
        colors = [(0,255,0), (0,255,255), (0,165,255), (0,0,255)]

        cv2.putText(frame, f"EAR: {avg_ear:.2f}", (30, 40),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255,255,255), 2)

        cv2.putText(frame, status_text[level], (30, 80),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, colors[level], 2)

    cv2.imshow("Eye Closure Detection (Buzzer System)", frame)

    if cv2.waitKey(1) & 0xFF == 27:
        break

# ---------------- CLEANUP ----------------
cap.release()
cv2.destroyAllWindows()
arduino.close()
